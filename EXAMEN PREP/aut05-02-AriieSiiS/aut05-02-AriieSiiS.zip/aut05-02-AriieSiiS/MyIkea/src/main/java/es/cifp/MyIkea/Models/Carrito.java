package es.cifp.MyIkea.Models;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "carrito")
public class Carrito {
    @Id
    @GeneratedValue
    private Long carritoId;

    @Column(name = "product_id")
    private int productId;
    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    public Carrito(){
    }
    public Carrito(User userAct) {
        this.user = userAct;
    }
}
