package es.cifp.MyIkea.controllers;

import org.springframework.ui.Model;
import es.cifp.MyIkea.Models.User;
import es.cifp.MyIkea.Models.UserDto;
import es.cifp.MyIkea.services.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.security.core.Authentication;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Controller
public class AuthController {
    @Autowired
    private UserService userService;
    @ModelAttribute("user")
    public UserDto userDto() {
        return new UserDto();
    }
    @GetMapping("/register")
    public String showRegisterForm() {
        return "register";
    }
    @PostMapping("/register")
    public String registerUser(@ModelAttribute("user") UserDto userDto) {
        userService.createUser(userDto.getUsername(), userDto.getEmail(), userDto.getPassword());
        return "redirect:/login";
    }
    @GetMapping("/login")
    public String showLoginForm() {
        return "login";
    }
    @PreAuthorize("hasAnyRole('ADMIN')")
    @GetMapping("/usuarios/lista")
    public String userList(Model model, Authentication authentication) {
        String currentUsername = authentication.getName();
        List<User> users = userService.getAllUsers();

        List<User> filteredUsers = users.stream()
                .filter(user -> !user.getEmail().equals(currentUsername))
                .collect(Collectors.toList());

        model.addAttribute("users", filteredUsers);
        return "usuarios/lista";
    }
    @PreAuthorize("hasAnyRole('ROLE_ADMIN')")
    @GetMapping("/usuarios/eliminar/{id}")
    public String deleteUser(@PathVariable long id, Authentication authentication) {
        String currentUsername = authentication.getName();
        Optional<User> userToDelete = userService.findById(id);

        if (!userToDelete.get().getEmail().equals(currentUsername)) {
            userService.deleteById(id);
        }
        return "redirect:/usuarios/lista";
    }

}
