package es.cifp.MyIkea.Repositories;



import es.cifp.MyIkea.Models.Carrito;
import es.cifp.MyIkea.Models.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CarritoRepository extends JpaRepository<Carrito, Long> {
    List<Carrito> getCarritosByUser(User user);
    void deleteCarritosByUser(User user);
}
