package es.cifp.MyIkea.services;

import es.cifp.MyIkea.Models.Producto;
import es.cifp.MyIkea.Repositories.ProductoRepository;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@Primary
public class ProductoService {
    private final ProductoRepository productoRepository;

    public ProductoService(ProductoRepository productRepository){ this.productoRepository = productRepository; }

    public List<Producto> getAllProducts(){ return  productoRepository.findAll(); }

    public Optional<Producto> getProductById(long id){return  productoRepository.findById(id);}

    public Producto saveProduct(Producto product){return  productoRepository.save(product);}
}
