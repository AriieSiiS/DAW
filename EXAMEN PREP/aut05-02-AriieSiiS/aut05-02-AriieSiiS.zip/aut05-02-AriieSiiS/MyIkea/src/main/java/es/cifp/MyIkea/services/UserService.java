package es.cifp.MyIkea.services;

import es.cifp.MyIkea.Models.User;
import es.cifp.MyIkea.Models.Role;
import es.cifp.MyIkea.Repositories.RoleRepository;
import es.cifp.MyIkea.Repositories.UserRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.util.Optional;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Transactional
@Service
public class UserService implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private RoleRepository roleRepository;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        User user = userRepository.findByEmail(email);

        if (user == null) {
            throw new UsernameNotFoundException("Usuario no encontrado: " + email);
        }

        user.getRoles().size(); // eager load

        return org.springframework.security.core.userdetails.User
                .withUsername(user.getEmail())
                .password(user.getPassword())
                .roles(user.getRoles().stream().map(Role::getName).toArray(String[]::new))
                .build();
    }
    public User createUser(String username, String email, String password) {

        String encodedPassword = encodePassword(password);

        Role userRole = roleRepository.findByName("USER");

        User user = new User();
        user.setUserName(username);
        user.setEmail(email);
        user.setPassword(encodedPassword);

        Set<Role> userRoles = new HashSet<>();
        userRoles.add(userRole);
        user.setRoles(userRoles);

        return userRepository.save(user);
    }
    private String encodePassword(String password) {
        PasswordEncoder encoder = new BCryptPasswordEncoder();
        return encoder.encode(password);
    }
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }
    public void deleteById(Long id) {
        userRepository.deleteById(id);
    }
    public Optional<User> findById(Long id) {
        return userRepository.findById(id);
    }

    public User loadUserDefault(String userMail) throws UsernameNotFoundException {
        Optional<User> userOptional = Optional.ofNullable(userRepository.findByEmail(userMail));
        return userOptional.orElseThrow(() -> new UsernameNotFoundException("Usuario no encontrado: " + userMail));
    }
}
