package es.cifp.MyIkea.Repositories;

import es.cifp.MyIkea.Models.Pedido;
import es.cifp.MyIkea.Models.User;
import es.cifp.MyIkea.Models.Carrito;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PedidoRepository extends JpaRepository<Pedido, Long> {
    List<Pedido> getPedidosByUser(User user);
}
