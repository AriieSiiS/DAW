package es.cifp.MyIkea.Models;

import jakarta.persistence.*;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
@Entity
@Table(name = "provincias")
public class Provincia {

    @Id
    @Column(name = "id_provincia")
    private Short idProvincia;

    @Column(name = "nombre", nullable = false)
    private String nombre;

    @OneToMany(mappedBy = "provincia")
    private List<Municipio> municipios;
}