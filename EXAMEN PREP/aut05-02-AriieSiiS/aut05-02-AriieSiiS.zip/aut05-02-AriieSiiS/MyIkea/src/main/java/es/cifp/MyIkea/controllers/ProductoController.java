package es.cifp.MyIkea.controllers;

import es.cifp.MyIkea.Models.Municipio;
import es.cifp.MyIkea.Models.Provincia;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.ui.Model;
import es.cifp.MyIkea.services.ProductoService;
import es.cifp.MyIkea.Models.Producto;
import java.util.Optional;
import es.cifp.MyIkea.services.ProvinciaService;
import es.cifp.MyIkea.services.MunicipioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class ProductoController {
    @Autowired
    private ProductoService productoService;
    @Autowired
    private MunicipioService municipioService;
    @Autowired
    private ProvinciaService provinciaService;

    @GetMapping("/productos/lista")
    public String getAllProducts(Model model)  {
        List<Producto> productos = productoService.getAllProducts();
        model.addAttribute("productos", productos);
        return "productos/lista";
    }

    @PreAuthorize("hasAnyRole('USER')")
    @GetMapping("/productos/detalles/{id}")
    public String verDetalles(@PathVariable("id") int productId, Model model) {
        Optional<Producto> productoOptional = productoService.getProductById(productId);
        Producto producto = productoOptional.orElse(null);
        model.addAttribute("product", producto);
        return "productos/detalles";
    }

    @PreAuthorize("hasAnyRole('ROLE_MANAGER')")
    @GetMapping("/productos/crear")
    public String mostrarFormularioCreacion(Model model) {
        List<Municipio> municipios = municipioService.getAllMunicipios();
        List<Provincia> provincias = provinciaService.getAllProvincias();
        model.addAttribute("newProduct", new Producto());
        model.addAttribute("municipios", municipios);
        model.addAttribute("provincias", provincias);

        return "productos/crear";
    }

    @PreAuthorize("hasAnyRole('ROLE_MANAGER')")
    @PostMapping("/productos/crear")
    public String crearProducto(@ModelAttribute("newProduct") Producto producto){
        productoService.saveProduct(producto);
        return "redirect:/productos/lista";
    }

}
