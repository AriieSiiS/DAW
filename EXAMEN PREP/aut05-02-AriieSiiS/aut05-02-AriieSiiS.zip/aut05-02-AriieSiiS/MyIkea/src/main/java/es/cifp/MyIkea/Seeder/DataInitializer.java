package es.cifp.MyIkea.Seeder;

import es.cifp.MyIkea.Models.Role;
import es.cifp.MyIkea.Models.User;
import es.cifp.MyIkea.Repositories.RoleRepository;
import es.cifp.MyIkea.Repositories.UserRepository;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Transactional
@RequiredArgsConstructor
@Service
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;

    @Transactional
    @Override
    public void run(String... args) throws Exception {

        Role rolUser = roleRepository.findByName("USER");
        if (rolUser == null) {
            rolUser = new Role();
            rolUser.setName("USER");
            roleRepository.save(rolUser);
        }

        Role rolManager = roleRepository.findByName("MANAGER");
        if (rolManager == null) {
            rolManager = new Role();
            rolManager.setName("MANAGER");
            roleRepository.save(rolManager);
        }

        Role rolAdmin = roleRepository.findByName("ADMIN");
        if (rolAdmin == null) {
            rolAdmin = new Role();
            rolAdmin.setName("ADMIN");
            roleRepository.save(rolAdmin);
        }

        User user = userRepository.findByEmail("user@ikea.com");
        if (user == null) {
            user = new User();
            user.setUserName("user");
            user.setEmail("user@ikea.com");
            user.setPassword(new BCryptPasswordEncoder().encode("Abcd1234!"));
            user.getRoles().add(rolUser);
            userRepository.save(user);
        }

        User manager = userRepository.findByEmail("manager@ikea.com");
        if (manager == null) {
            manager = new User();
            manager.setUserName("manager");
            manager.setEmail("manager@ikea.com");
            manager.setPassword(new BCryptPasswordEncoder().encode("Abcd1234!"));
            manager.getRoles().add(rolUser);
            manager.getRoles().add(rolManager);
            userRepository.save(manager);
        }

        User admin = userRepository.findByEmail("admin@ikea.com");
        if (admin == null) {
            admin = new User();
            admin.setUserName("admin");
            admin.setEmail("admin@ikea.com");
            admin.setPassword(new BCryptPasswordEncoder().encode("Abcd1234!"));
            admin.getRoles().add(rolUser);
            admin.getRoles().add(rolAdmin);
            userRepository.save(admin);
        }
    }
}
