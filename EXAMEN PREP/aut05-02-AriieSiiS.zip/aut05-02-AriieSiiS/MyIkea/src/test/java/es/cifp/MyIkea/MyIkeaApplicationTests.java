package es.cifp.MyIkea;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyIkeaApplicationTests {

	@Test
	void contextLoads() {
	}

}
