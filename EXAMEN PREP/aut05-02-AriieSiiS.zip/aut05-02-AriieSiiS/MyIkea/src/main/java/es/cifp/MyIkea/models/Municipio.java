package es.cifp.MyIkea.models;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.LinkedHashSet;
import java.util.Set;

@Getter
@Setter
@Entity
@Table(name = "municipios")
public class Municipio {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_municipio")
    private Short idMunicipio;

    @Column(name = "id_provincia", nullable = false)
    private Short idProvincia;

    @Column(name = "cod_municipio", nullable = false)
    private Integer codMunicipio;

    @Column(name = "DC", nullable = false)
    private Integer dc;

    @Column(name = "nombre", nullable = false)
    private String nombre;

    @ManyToOne
    @JoinColumn(name = "id_provincia", referencedColumnName = "id_provincia", insertable = false, updatable = false)
    private Provincia provincia;

    @OneToMany(mappedBy = "municipio")
    private Set<Producto> productos = new LinkedHashSet<>();
}