package es.cifp.MyIkea.services;

import es.cifp.MyIkea.models.Provincia;
import es.cifp.MyIkea.repositories.ProvinciaRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import java.util.List;

@Primary
@Service
public class ProvinciaService {

    @Autowired
    private ProvinciaRepository provinciaRepository;
    public List<Provincia> getAllProvincias(){ return  provinciaRepository.findAll(); }
}