package es.cifp.MyIkea.services;

import es.cifp.MyIkea.models.Municipio;
import es.cifp.MyIkea.repositories.MunicipioRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
@Primary
public class MunicipioService {

    @Autowired
    private MunicipioRepository municipioRepository;

    public List<Municipio> getAllMunicipios(){ return  municipioRepository.findAll();}
}