package es.cifp.MyIkea.controllers;

import org.springframework.ui.Model;
import es.cifp.MyIkea.services.ProductoService;
import es.cifp.MyIkea.models.Producto;

import es.cifp.MyIkea.services.ProvinciaService;
import es.cifp.MyIkea.services.MunicipioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class ProductoController {
    @Autowired
    private ProductoService productoService;
    @Autowired
    private MunicipioService municipioService;
    @Autowired
    private ProvinciaService provinciaService;

    @GetMapping("/productos/lista")
    public String getAllProducts(Model model)  {
        List<Producto> productos = productoService.getAllProducts();
        model.addAttribute("productos", productos);
        return "productos/lista";
    }

}
