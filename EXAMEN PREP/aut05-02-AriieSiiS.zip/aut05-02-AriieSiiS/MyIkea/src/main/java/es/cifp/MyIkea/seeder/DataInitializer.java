package es.cifp.MyIkea.seeder;

import es.cifp.MyIkea.models.Role;
import es.cifp.MyIkea.repositories.RoleRepository;
import es.cifp.MyIkea.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Service;

@Service
public class DataInitializer implements CommandLineRunner {
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private RoleRepository roleRepository;

    @Override
    public void run(String... args) throws Exception {
        createRoleIfNotFound("USER");
        createRoleIfNotFound("MANAGER");
        createRoleIfNotFound("ADMIN");
    }
    private void createRoleIfNotFound(String roleName) {
        Role role = roleRepository.findByName(roleName);
        if (role == null) {
            role = new Role();
            role.setName(roleName);
            roleRepository.save(role);
        }
    }
}
