﻿using System;

namespace Ejercicio
{
    class Ejercicio
    {
        static void Main(String[] args)
        {
            for (int i = 1; i <= 100; i++)
            {
                Console.WriteLine(i);
            }
        }
    }
}



