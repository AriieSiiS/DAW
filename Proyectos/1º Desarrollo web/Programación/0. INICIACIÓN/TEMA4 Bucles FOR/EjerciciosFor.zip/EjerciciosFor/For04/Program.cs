﻿
using System;

namespace Ejercicio
{
    class Ejercicio
    {
        static void Main(String[] args)
        {

            for (int i = 100; i >= 0; i--)
            {
                Console.WriteLine(i);
            }
        }
    }
}


