﻿using System;

namespace Ejercicio
{
    class Ejercicio
    {
        static void Main(String[] args)
        {
            Console.WriteLine("Vamos a escribir Hola cinco veces");
            for (int i = 0;  i < 5; i++)
            {
                Console.WriteLine("Hola");
            }
        }
    }
}

